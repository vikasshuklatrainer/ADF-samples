# 🚀 Azure Logic App: JSON to SQL Ingestion

## 📌 Overview
This Logic App reads a JSON file from Azure Blob Storage and inserts records into an Azure SQL table.

---

## 🏗️ Architecture

Blob Storage (JSON File)
        ↓
Logic App Trigger
        ↓
Get Blob Content
        ↓
Parse JSON
        ↓
For Each Record
        ↓
Insert Row (SQL)

---

## ⚙️ Prerequisites

- Azure Storage Account
- Azure SQL Database
- Logic App (Consumption/Standard)

---

## 🧱 SQL Table Schema

```sql
CREATE TABLE Employees (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name VARCHAR(100),
    Department VARCHAR(50),
    Salary DECIMAL(10,2),
    JoinDate DATE,
    Email VARCHAR(100),
    City VARCHAR(50),
    Country VARCHAR(50),
    EmploymentType VARCHAR(50),
    YearsExperience INT,
    IsActive BIT
);
```

---

## 🧱 Implementation Steps

### 1. Trigger
Use: When a blob is added or modified OR Recurrence

### 2. Get Blob Content
Use Azure Blob Storage connector

### 3. Parse JSON

```json
{
  "type": "array",
  "items": {
    "type": "object",
    "properties": {
      "Name": { "type": "string" },
      "Department": { "type": "string" },
      "Salary": { "type": "number" },
      "JoinDate": { "type": "string" },
      "Email": { "type": "string" },
      "City": { "type": "string" },
      "Country": { "type": "string" },
      "EmploymentType": { "type": "string" },
      "YearsExperience": { "type": "integer" },
      "IsActive": { "type": "boolean" }
    }
  }
}
```

### 4. For Each
Loop through parsed JSON array

### 5. Insert Row
Use Insert Row (V2) and map fields

---

## 🧪 Testing

1. Upload JSON file
2. Run Logic App
3. Verify SQL table

---

## ✅ Conclusion

Serverless pipeline to ingest JSON into SQL using Azure Logic Apps.
